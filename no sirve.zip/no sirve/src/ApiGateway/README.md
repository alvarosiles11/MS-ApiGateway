# MS Api Gateway

### 1.-archivo creo Api.Gateway

cmd: dotnet new webapi -o Api.Gateway

### 2.- dentro del proyecto Api.Gateway

cmd: dotnet add package Ocelot --version 18.0.0

### 3.- creo un archivo Ocelot.json en proyecto Api.Gateway

### 4.- dentro del proyecto Api.Gateway

cmd: dotnet add package Microsoft.EntityFrameworkCore.Tools --version 6.0.8

### 5.- dentro del proyecto Api.Gateway

cmd: dotnet run
